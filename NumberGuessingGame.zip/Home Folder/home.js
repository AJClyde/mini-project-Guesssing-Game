function startGame() {
  let min = 
  Number(document.getElementById("min").value);
  let max =
  Number(document.getElementById("max").value);
  
  if (!min || !max || min >= max) {
    alert("Please enter a valid range!")
    return;
  }
  
  // save value
  localStorage.setItem("min", min);
  localStorage.setItem("max", max);
  
  // go to game 
  window.location.href = "/Game Folder/game.html";
}